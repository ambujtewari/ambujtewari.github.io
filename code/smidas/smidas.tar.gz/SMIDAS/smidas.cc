//  Copyright 2010 Shai Shalev-Shwartz, Ambuj Tewari

//  SMIDAS version 1.1

/*
    This file is part of SMIDAS.

    SMIDAS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    SMIDAS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with SMIDAS. If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <cstdlib>
#include <vector>
#include <ctime>
#include <cmath>

#include "cmd_line.h"
#include "Losses.h"

/*
class my_pair {
public:
  my_pair() : first(0), second(0.0) { }
  my_pair(unsigned int f,double s) : first(f), second(s) { }
  my_pair(std::ifstream& fid) : first(0), second(0.0) {
    fid >> first; fid >> second;
  }
  ~my_pair() { }
  unsigned int first;
  double second;
};
*/


class my_dataset {
public:
  my_dataset(std::ifstream &my_file, unsigned int m) : 
    LinesFirst(m), LinesSecond(m), LinesSize(m) {
    for (unsigned int i=0; i<m; ++i) {
      unsigned int r;
      my_file >> r;
      LinesSize[i] = r;
      LinesFirst[i] = new unsigned int[r];
      LinesSecond[i] = new double[r];
      for (unsigned int j=0; j<r; ++j) {
	unsigned int tmp1; double tmp2;
	my_file >> tmp1 >> tmp2;
	LinesFirst[i][j] = tmp1;
	LinesSecond[i][j] = tmp2;
      }
    }
  }

  ~my_dataset() {
    for (unsigned int i=0; i<LinesFirst.size(); ++i) {
      delete[] LinesFirst[i];
      delete[] LinesSecond[i];
    }
  }

  unsigned int size() {return(LinesFirst.size());}
  unsigned int size(unsigned int i) {return(LinesSize[i]);}
  double second(unsigned int i, unsigned int j) {
    return(LinesSecond[i][j]);
  }
  unsigned int first(unsigned int i,unsigned int j) {
    return(LinesFirst[i][j]);
  }

protected:
  std::vector< unsigned int * > LinesFirst;
  std::vector< double * > LinesSecond;
  std::vector< unsigned int > LinesSize;
};


// testing module
void test_and_print(std::vector<double>& w,double w_scale,
		    my_dataset &X,std::vector<double> &Y,double lambda,
		    Losses &L) {
  
  unsigned int m = X.size();
  unsigned int d = w.size();

  // calcuate its 1-norm and sparsity
  double w_norm = 0.0; 
  unsigned int w_density = 0;
  for (unsigned int t=0; t<d; ++t) {
    double tmp = fabs(w[t])/w_scale;
    w_norm += tmp;
    if (tmp > 0.0000001) w_density++;
  }
  
  // go over all examples and calculate cumulative loss
  double cum_loss = 0.0;
  double cum_mistakes = 0.0;
  
  for (unsigned int i=0; i < m; ++i) {
    
    // calculate loss of w on (X,y)
    double z = 0.0;
    for (unsigned int j=0;j < X.size(i); ++j) {
      z += w[X.first(i,j)]/w_scale*X.second(i,j);
    }    

    cum_loss += L.loss(z,Y[i]);
    if (Y[i]*z <= 0.0) cum_mistakes++;
  }
  cum_loss /= m;
  cum_mistakes /= m;
  
  // Report
  std::cout << w_norm << " " << w_density << " " 
	    << cum_loss << " " << cum_loss+lambda*w_norm 
	    << " " << cum_mistakes << "\n";
  
}


int main(int argc, char** argv) {
  
  
  // -------------------------------------------------------------
  // ---------------------- Parse Command Line -------------------
  // -------------------------------------------------------------
  std::string instances_filename;
  std::string labels_filename;
  unsigned int n_iters,loss_type,print_me;
  double lambda,eta;
  
  // parse command line
  learning::cmd_line cmdline;
  cmdline.info("SMIDAS -- L_1 regularized loss minimization");
  cmdline.add_master_option("<instances-file>", &instances_filename);
  cmdline.add_master_option("<labels-file>", &labels_filename);
  cmdline.add("-lambda", "regularization parameter (default = 0.001)", &lambda, 0.001);
  cmdline.add("-iters", "number of iterations (default = 1000)", &n_iters, 1000);
  cmdline.add("-eta", "learning rate (default = 0.001)", &eta, 0.001);
  cmdline.add("-loss","0 for logistic, 1 for hinge, 2 for squared loss (default = 0)",&loss_type,0);
  cmdline.add("-printout","after how many iterations to print w (default 1000)",&print_me,1000);

  int rc = cmdline.parse(argc, argv);
  if (rc < 2) {
    cmdline.print_help();
    return EXIT_FAILURE;
  }

  // choose a random seed
  srand(time(NULL));


  // -------------------------------------------------------------
  // ---------------------- Read data ----------------------------
  // -------------------------------------------------------------

  // read data
  std::ifstream my_file(instances_filename.c_str());
  if (!my_file.good()) perror(instances_filename.c_str());
  unsigned int m,d,r;
  my_file >> m; my_file >> d;
  my_dataset X(my_file,m);
  my_file.close();

  // read labels
  std::ifstream label_file(labels_filename.c_str());
  if (!label_file.good()) perror(labels_filename.c_str());
  std::vector<double> Y(m);
  for (unsigned int i=0; i<m; ++i) {
    double y; label_file >> y; Y[i] = y;
  }
  label_file.close();
  
  // std::cerr << "done reading data\n";

  // -------------------------------------------------------------
  // --------------- Construct Loss ------------------------------
  // -------------------------------------------------------------

  Losses L(loss_type);
  
  // -------------------------------------------------------------
  // --------------- The Algorithm -------------------------------
  // -------------------------------------------------------------

  // the total number of accesses to the data matrix
  unsigned long long num_accesses=0;

  // set the p-norm parameter
  double p = floor(2*log(d));

  // Initilize theta and w
  std::vector<double> w(d); double w_scale = 1.0;
  std::vector<double> theta(d);
  for (unsigned int i=0; i<d; ++i) {
    w[i]=0.0; theta[i]=0.0;
  }
  double theta_p = 0.0; // this will contain sum_i |theta_i|^{p}
  
  // start a clock
  clock_t start = clock();
  clock_t elapsed = 0;

  // Main Loop
  for (unsigned int iter=0; iter<n_iters; ++iter) {
    
    // Choose a random instance
    unsigned int ind = (((int)rand()) % m);
    //   std::vector<my_pair>& x = X[ind];
    
    // Calculate inner products of w with x
    double z = 0.0;
#ifndef _LANGFORD_
    if (w_scale > 0.0) {
      for (unsigned int j=0;j < X.size(ind); ++j) {
	z += w[X.first(ind,j)]/w_scale*X.second(ind,j);
      }

      num_accesses += X.size(ind);
    }
#else
      for (unsigned int j=0;j < X.size(ind); ++j) {
	z += theta[X.first(ind,j)]*X.second(ind,j);

      }    

      num_accesses += X.size(ind);
#endif
    
    // calculate gradient of loss
    double g=L.loss_grad(z,Y[ind]);

    // update theta and w
#ifndef _LANGFORD_
    theta_p = 0;
#endif
    for (unsigned int j=0;j < X.size(ind); ++j) {
      unsigned int t = X.first(ind,j);
      theta[t] -= eta*g*X.second(ind,j);
    }

    for (unsigned int t=0; t < d; ++t) { 
      if (theta[t] > 0.0) {
	theta[t] -= eta*lambda;
	if (theta[t] < 0.0) theta[t] = 0.0;
      } else {
	theta[t] += eta*lambda;
	if (theta[t] > 0.0) theta[t] = 0.0;
      }
      if (fabs(theta[t]) < 0.0000001) theta[t] = 0.0; // rounding errors


#ifndef _LANGFORD_
      // update theta_p
      theta_p += pow(fabs(theta[t]),p);

      // update w
      if (theta[t] >= 0.0)
	w[t] = pow(theta[t],p-1);
      else
	w[t] = -pow(-theta[t],p-1);
#endif
    }
    
    num_accesses += X.size(ind);

#ifndef _LANGFORD_
    // update normalization factor
    w_scale = pow(theta_p,1-2/p);
#endif
    

    // Once in a while, report results
    if ((iter % (print_me)) == print_me-1) {
      // stop time and print time elapsed, number of data accesses and the weight vector
      elapsed += clock()-start;
      std::cout << (((double)elapsed/(double)CLOCKS_PER_SEC)*1000)  
		<< " " << num_accesses << " ";
#ifndef _LANGFORD_

      test_and_print(w,w_scale,X,Y,lambda,L);
      
#else
      test_and_print(theta,1.0,X,Y,lambda,L);
#endif

      // continue time
      start = clock();
    }
  
    
  }
  

  return(EXIT_SUCCESS);

}


